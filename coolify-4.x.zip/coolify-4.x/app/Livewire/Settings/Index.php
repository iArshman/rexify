<?php

namespace App\Livewire\Settings;

use App\Models\InstanceSettings;
use App\Models\Server;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Validate;
use Livewire\Component;

class Index extends Component
{
    public InstanceSettings $settings;

    public ?Server $server = null;

    #[Validate('nullable|string|max:255|url')]
    public ?string $fqdn = null;

    #[Validate('required|integer|min:1025|max:65535')]
    public int $public_port_min;

    #[Validate('required|integer|min:1025|max:65535')]
    public int $public_port_max;

    #[Validate('nullable|string|max:255')]
    public ?string $instance_name = null;

    #[Validate('nullable|ipv4')]
    public ?string $public_ipv4 = null;

    #[Validate('nullable|ipv6')]
    public ?string $public_ipv6 = null;

    #[Validate('required|string|timezone')]
    public string $instance_timezone;

    #[Validate(['nullable', 'string', 'max:128', 'regex:/^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/'])]
    public ?string $dev_helper_version = null;

    public array $domainConflicts = [];

    public bool $showDomainConflictModal = false;

    public bool $forceSaveDomains = false;

    public $buildActivityId = null;

    protected array $messages = [
        'fqdn.url' => 'Invalid instance URL.',
        'fqdn.max' => 'URL must not exceed 255 characters.',
        'dev_helper_version.regex' => 'Dev helper version must match Docker tag format (alphanumeric, _, ., -; first char cannot be . or -).',
    ];

    public function render()
    {
        return view('livewire.settings.index');
    }

    public function mount()
    {
        if (! isInstanceAdmin()) {
            return redirect()->route('dashboard');
        }
        $this->settings = instanceSettings();
        if (! isCloud()) {
            $this->server = Server::findOrFail(0);
        }
        $this->fqdn = $this->settings->fqdn;
        $this->public_port_min = $this->settings->public_port_min;
        $this->public_port_max = $this->settings->public_port_max;
        $this->instance_name = $this->settings->instance_name;
        $this->public_ipv4 = $this->settings->public_ipv4;
        $this->public_ipv6 = $this->settings->public_ipv6;
        $this->instance_timezone = $this->settings->instance_timezone;
        $this->dev_helper_version = $this->settings->dev_helper_version;
    }

    #[Computed]
    public function timezones(): array
    {
        return collect(timezone_identifiers_list())
            ->sort()
            ->values()
            ->toArray();
    }

    public function instantSave($isSave = true)
    {
        $this->validate();
        $this->settings->fqdn = $this->fqdn ? trim($this->fqdn) : $this->fqdn;
        $this->settings->public_port_min = $this->public_port_min;
        $this->settings->public_port_max = $this->public_port_max;
        $this->settings->instance_name = $this->instance_name;
        $this->settings->public_ipv4 = $this->public_ipv4;
        $this->settings->public_ipv6 = $this->public_ipv6;
        $this->settings->instance_timezone = $this->instance_timezone;
        $this->settings->dev_helper_version = $this->dev_helper_version;
        if ($isSave) {
            $this->settings->save();
            $this->dispatch('success', 'Settings updated!');
        }
    }

    public function confirmDomainUsage()
    {
        $this->forceSaveDomains = true;
        $this->showDomainConflictModal = false;
        $this->submit();
    }

    public function submit()
    {
        try {
            $error_show = false;
            $this->resetErrorBag();

            if (! validate_timezone($this->instance_timezone)) {
                $this->instance_timezone = config('app.timezone');
                throw new \Exception('Invalid timezone.');
            } else {
                $this->settings->instance_timezone = $this->instance_timezone;
            }

            if ($this->settings->public_port_min > $this->settings->public_port_max) {
                $this->addError('settings.public_port_min', 'The minimum port must be lower than the maximum port.');

                return;
            }

            // Trim FQDN to remove leading/trailing whitespace before validation
            if ($this->fqdn) {
                $this->fqdn = trim($this->fqdn);
            }

            $this->validate();

            if ($this->settings->is_dns_validation_enabled && $this->fqdn && $this->server) {
                if (! validateDNSEntry($this->fqdn, $this->server)) {
                    $this->dispatch('error', "Validating DNS failed.<br><br>Make sure you have added the DNS records correctly.<br><br>{$this->fqdn}->{$this->server->ip}<br><br>Check this <a target='_blank' class='underline dark:text-white' href='https://coolify.io/docs/knowledge-base/dns-configuration'>documentation</a> for further help.");
                    $error_show = true;
                }
            }
            if ($this->fqdn) {
                if (! $this->forceSaveDomains) {
                    $result = checkDomainUsage(domain: $this->fqdn);
                    if ($result['hasConflicts']) {
                        $this->domainConflicts = $result['conflicts'];
                        $this->showDomainConflictModal = true;

                        return;
                    }
                } else {
                    // Reset the force flag after using it
                    $this->forceSaveDomains = false;
                }
            }

            $this->instantSave(isSave: false);

            $this->settings->save();
            if ($this->server) {
                $this->server->setupDynamicProxyConfiguration();
            }
            if (! $error_show) {
                $this->dispatch('success', 'Instance settings updated successfully!');
            }
        } catch (\Exception $e) {
            return handleError($e, $this);
        }
    }

    public function buildHelperImage()
    {
        try {
            if (! isDev()) {
                $this->dispatch('error', 'Building helper image is only available in development mode.');

                return;
            }

            if (! $this->server) {
                $this->dispatch('error', 'Server not available.');

                return;
            }

            $this->validateOnly('dev_helper_version');

            $version = $this->dev_helper_version ?: config('constants.coolify.helper_version');
            if (empty($version)) {
                $this->dispatch('error', 'Please specify a version to build.');

                return;
            }

            if (! preg_match('/^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/', (string) $version)) {
                $this->dispatch('error', 'Invalid helper version format.');

                return;
            }

            $imageRef = escapeshellarg("ghcr.io/coollabsio/coolify-helper:{$version}");
            $buildCommand = "docker build -t {$imageRef} -f docker/coolify-helper/Dockerfile .";

            $activity = remote_process(
                command: [$buildCommand],
                server: $this->server,
                type: 'build-helper-image'
            );

            $this->buildActivityId = $activity->id;
            $this->dispatch('activityMonitor', $activity->id);

            $this->dispatch('success', "Building coolify-helper:{$version}...");
        } catch (\Exception $e) {
            return handleError($e, $this);
        }
    }
}
