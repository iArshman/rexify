<?php

namespace App\Livewire\Project;

use App\Models\Project;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Livewire\Component;

class DeleteProject extends Component
{
    use AuthorizesRequests;

    public array $parameters;

    public int $project_id;

    public bool $disabled = false;

    public string $projectName = '';

    public function mount()
    {
        $this->parameters = get_route_parameters();
        $this->projectName = Project::ownedByCurrentTeam()->findOrFail($this->project_id)->name;
    }

    public function delete()
    {
        $this->validate([
            'project_id' => 'required|int',
        ]);
        $project = Project::ownedByCurrentTeam()->findOrFail($this->project_id);
        $this->authorize('delete', $project);

        if ($project->isEmpty()) {
            $project->delete();

            return redirectRoute($this, 'project.index');
        }

        return $this->dispatch('error', "<strong>Project {$project->name}</strong> has resources defined, please delete them first.");
    }
}
